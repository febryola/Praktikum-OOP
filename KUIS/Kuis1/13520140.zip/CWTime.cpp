/*
Nama : Febryola Kurnia Putri
NIM  : 13520140
Kelas: K02
Kuis 1
*/

#include <iostream>
using namespace std;
#include "CWTime.h"

CWTime :: CWTime(){
    this -> jam = 0;
    this -> menit = 0;
    this -> detik = 0;
    this -> layanan = "automatic";
}
CWTime :: CWTime(int h, int m, int s, string l){
    this -> jam = h;
    this -> menit = m;
    this -> detik = s;
    this -> layanan = l;
}

CWTime :: CWTime(int m, string l){
    this -> jam = 0;
    this -> menit = m;
    this -> detik = 0;
    this -> layanan = l;
}

float CWTime :: InMinutes()const{
    return jam*60+menit+detik*0.01;
}

CWTime CWTime :: operator+(int m){
    int result = this->menit;
    result += m;
    if (result > 60){
        this->jam+=result/60;
        this->menit=result%60;

    }
}

void CWTime :: Print()const{
  int h = this->detik / 3600;
  int m = (this->detik % 3600) / 60;
  int s = this->detik % 60;

  if (h < 10) {
    cout << "Waktu mencuci adalah 0" << h << ":";
  } else {
    cout << "Waktu mencuci adalah " << h << ":";
  }
  if (m < 10) {
    cout << "0" << m << ":";
  } else {
    cout << m << ":";
  }
  if (s < 10) {
    cout << "0" << s << endl;
  } else {
    cout << s << endl;
  }
  cout << "Layanan : " << this->layanan << endl;
}
string CWTime :: get_service(){
    return this->layanan;
}

CarWash :: CarWash (){
    this -> size = 100;
    this-> tail = 99;
    this->Array = new CarWash[this->size];
}

CarWash :: CarWash(int _size){
    this -> size = _size;
    this-> tail = 99;
    this->Array = new CarWash[this->size];
}
CarWash :: CarWash(const CarWash& C){
    this -> size = C.size;
    this-> tail = C.tail;
    this->Array = new CarWash[this->size];
    for (int i=0;i<this->size;i++){
        this->Array[i]=C.Array[i];
    }
}
CarWash :: ~CarWash(){
    delete [] this->Array;
}

CarWash& CarWash :: operator=(const CarWash& C){
    this -> size = C.size;
    this-> tail = C.tail;
    this->Array = new CarWash[this->size];
    for (int i=0;i<this->size;i++){
        this->Array[i]=C.Array[i];
    }
    return *this;
}

CarWash& CarWash::operator<<(const CWTime& Ct) {
  this->Array[this->tail] = Ct;
  this->tail++;
  return *this;
}

void CarWash::operator>>(CWTime& Ct) {
  Ct = this->Array[0];
  for (int i = 0; i < this->tail - 1; i++) {
    this->Array[i] = this->Array[i + 1];
  }
  this->tail--;
}
long CarWash :: BiayaCuci(CWTime& Ct){
    if (Ct.get_service()='Automatic'){
        return 2000*Ct.InMinutes()+20000;
    }
    else{
        return 2000*Ct.InMinutes()+50000;
    }
}






