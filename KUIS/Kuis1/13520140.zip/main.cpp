#include <iostream>
#include "CWTime.h"
using namespace std;

int main() {
  CarWash CW;
  CW << CWTime(15, "automatic");
  CW << CWTime(15, "handwash");
  CW << CWTime(7, "automatic");
  CWTime waktu;
  CW >> waktu;
  waktu.Print();
  cout << CW.BiayaCuci(waktu) << endl << endl;
  CW >> waktu;
  waktu.Print();
  cout << CW.BiayaCuci(waktu) << endl << endl;
  CW >> waktu;
  waktu.Print();
  cout << CW.BiayaCuci(waktu) << endl << endl;
  waktu = CWTime(2, 3, 15, "automatic");
  waktu.Print();
  cout << CW.BiayaCuci(waktu) << endl;
  cout << waktu.InMinutes() << endl;
  return 0;
}