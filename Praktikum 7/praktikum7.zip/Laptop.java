public class Laptop {
    private String serialNumber = "abc";

    public Laptop() {
        //
    }
    public Integer getRamSize() {
        //
        Integer x = 2;
        return x;
    }
}